package com.example.mytouristapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // UI components
    TextView infoText;
    TextView counterText;
    Button btnParis, btnTokyo, btnNewYork, btnLondon;

    // Simple variables
    int visitCounter = 0;
    boolean parisVisited = false;
    boolean tokyoVisited = false;
    boolean newYorkVisited = false;
    boolean londonVisited = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find all views
        infoText = findViewById(R.id.infoText);
        counterText = findViewById(R.id.counterText);
        btnParis = findViewById(R.id.btnParis);
        btnTokyo = findViewById(R.id.btnTokyo);
        btnNewYork = findViewById(R.id.btnNewYork);
        btnLondon = findViewById(R.id.btnLondon);

        // Set button listeners - SIMPLE WAY
        btnParis.setOnClickListener(v -> showParis());

        btnTokyo.setOnClickListener(v -> showTokyo());

        btnNewYork.setOnClickListener(v -> showNewYork());

        btnLondon.setOnClickListener(v -> showLondon());
    }

    // Simple method for Paris
    private void showParis() {
        String info = "PARIS - The City of Light\n\n";
        info = info + "Population: 2.1 million\n";
        info = info + "Famous for: Eiffel Tower, Louvre Museum\n";
        info = info + "Best time to visit: April-June\n";
        info = info + "Must try: Croissants, Macarons\n";
        info = info + "Language: French\n\n";
        info = info + "Fun fact: The Eiffel Tower was built in 1889!";

        infoText.setText(info);

        // Check if first time visiting Paris
        if (!parisVisited) {
            parisVisited = true;
            visitCounter = visitCounter + 1;
            updateCounter();
        }
    }

    // Simple method for Tokyo
    private void showTokyo() {
        String info = "TOKYO - The Modern Metropolis\n\n";
        info = info + "Population: 13.9 million\n";
        info = info + "Famous for: Mount Fuji, Temples\n";
        info = info + "Best time to visit: March-May\n";
        info = info + "Must try: Sushi, Ramen\n";
        info = info + "Language: Japanese\n\n";
        info = info + "Fun fact: Tokyo has the busiest train station!";

        infoText.setText(info);

        // Check if first time visiting Tokyo
        if (!tokyoVisited) {
            tokyoVisited = true;
            visitCounter = visitCounter + 1;
            updateCounter();
        }
    }

    // Simple method for New York
    private void showNewYork() {
        String info = "NEW YORK - The Big Apple\n\n";
        info = info + "Population: 8.3 million\n";
        info = info + "Famous for: Statue of Liberty, Times Square\n";
        info = info + "Best time to visit: April-June\n";
        info = info + "Must try: Pizza, Bagels\n";
        info = info + "Language: English\n\n";
        info = info + "Fun fact: Central Park is very large!";

        infoText.setText(info);

        // Check if first time visiting New York
        if (!newYorkVisited) {
            newYorkVisited = true;
            visitCounter = visitCounter + 1;
            updateCounter();
        }
    }

    // Simple method for London
    private void showLondon() {
        String info = "LONDON - The Historic Capital\n\n";
        info = info + "Population: 8.9 million\n";
        info = info + "Famous for: Big Ben, London Eye\n";
        info = info + "Best time to visit: May-September\n";
        info = info + "Must try: Fish and Chips, Tea\n";
        info = info + "Language: English\n\n";
        info = info + "Fun fact: London has over 170 museums!";

        infoText.setText(info);

        // Check if first time visiting London
        if (!londonVisited) {
            londonVisited = true;
            visitCounter = visitCounter + 1;
            updateCounter();
        }
    }

    // Update counter with simple messages
    private void updateCounter() {
        String counterMessage = "Cities explored: " + visitCounter;
        counterText.setText(counterMessage);

        // Simple if-else for congratulations
        if (visitCounter == 1) {
            String currentInfo = infoText.getText().toString();
            String newInfo = currentInfo + "\n\nCongratulations! You started your journey!";
            infoText.setText(newInfo);
        } else if (visitCounter == 2) {
            String currentInfo = infoText.getText().toString();
            String newInfo = currentInfo + "\n\nGreat! Keep exploring!";
            infoText.setText(newInfo);
        } else if (visitCounter == 3) {
            String currentInfo = infoText.getText().toString();
            String newInfo = currentInfo + "\n\nAwesome! Almost done!";
            infoText.setText(newInfo);
        } else if (visitCounter == 4) {
            String currentInfo = infoText.getText().toString();

            // Simple for loop to create stars
            StringBuilder stars = new StringBuilder();
            for (int i = 0; i < 5; i++) {
                stars.append("*");
            }

            String newInfo = currentInfo + "\n\nAmazing! You explored all cities!\n" + stars + " WORLD TRAVELER " + stars;
            infoText.setText(newInfo);
        }
    }
}